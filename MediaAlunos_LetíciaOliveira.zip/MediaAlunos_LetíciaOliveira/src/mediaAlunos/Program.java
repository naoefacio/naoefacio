package mediaAlunos;

import java.util.Scanner;

import menu.AtualizaAluno;
import menu.ConsultaAluno;
import menu.InsereAluno;
import menu.ItemDeMenu;
import menu.ListaAp;
import menu.ListaAluno;
import menu.ListaMedia;
import menu.ListaNome;
import menu.ListaRp;
import menu.RemoveAluno;
import menu.Sair;

public class Program {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);

		ItemDeMenu[] principal = new ItemDeMenu[] { 
				new InsereAluno(),
				new ListaNome(),
				new ConsultaAluno(),
				new AtualizaAluno(),
				new RemoveAluno(),
				new ListaAp(),
				new ListaRp(),
				new ListaMedia(),
				new Sair() 
		};

		boolean sair = false;
		do {
			for (int i = 0; i < principal.length; i++) {
				System.out.println(i + " - " + principal[i].getDescricao());
			}
			System.out.print("Digite a opção desejada: ");
			int opcao = Integer.parseInt(console.nextLine());

			sair = principal[opcao].executar();
		} while (!sair);
	}

}
