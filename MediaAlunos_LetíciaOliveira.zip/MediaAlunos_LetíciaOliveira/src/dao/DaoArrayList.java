package dao;

import java.util.ArrayList;

import modelo.Aluno;

public class DaoArrayList implements Dao {
    
    //bd = banc de dados aluno

	private static ArrayList<Aluno> bd = new ArrayList<Aluno>();

	@Override
	public void inserir(Aluno aluno) {
		bd.add(aluno);
	}
//não entendi o porque desse override
	@Override
	public ArrayList<Aluno> listar() {
		return bd;
	}

	@Override
	public Aluno pesquisar(String matricula) {
		Aluno resultado = null;

		for (int i = 0; i < bd.size(); i++) {
			Aluno atual = bd.get(i);
			
			if (atual.getMatricula().equals(matricula)) {
				resultado = atual;
				break;
			}
		}
		return resultado;
	}
	
	@Override
	public void atualizar(Aluno aluno) {
		Aluno pesquisado = pesquisar(aluno.getMatricula());
		
		pesquisado.setNome(aluno.getNome());
		pesquisado.setT1(aluno.getT1());
		pesquisado.setT2(aluno.getT2());
                pesquisado.setT3(aluno.getT3());
	}
	
        @Override
	public void remover(Aluno aluno) {
		bd.remove(aluno);
	}
}
