package menu;

import modelo.Aluno;

public class AtualizaAluno extends ItemDeMenu {

	@Override
	public String getDescricao() {
		return "Atualizar aluno";
	}

	@Override
	public boolean executar() {
		String matricula = leitor.lerString("Matrícula Nº: ");

		Aluno aluno = dao.pesquisar(matricula);

		if (aluno == null) {
			System.out.println("Aluno não encontrado!");
		}
		else {
			System.out.println("Nome: " + aluno.getNome());
			System.out.println("1º Trimestre: " + aluno.getT1());
			System.out.println("2º Trimestre: " + aluno.getT2());
                        System.out.println("3º Trimestre: " + aluno.getT3());
			
			String nome = leitor.lerString("Novo nome: ");
			double t1 = leitor.lerDouble("Nova nota 1: ");
			double t2 = leitor.lerDouble("Nova nota 2: ");
                        double t3 = leitor.lerDouble("Nova nota 3: ");
			
			aluno.setNome(nome);
			aluno.setT1(t1);
			aluno.setT2(t2);
                        aluno.setT3(t3);
			
			dao.atualizar(aluno);
		}

		return false;
	}

}
