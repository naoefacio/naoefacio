package menu;

import modelo.Aluno;

public class ListaNome extends ListaAluno {

	@Override
	public String getDescricao() {
		return "Listar alunos (ordem alfab�tica)";
	}

	@Override
	public boolean deveImprimir(Aluno aluno) {
		return true;
	}

}
