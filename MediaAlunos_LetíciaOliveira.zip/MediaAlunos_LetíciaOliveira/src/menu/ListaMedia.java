package menu;

import modelo.Aluno;

public class ListaMedia extends ListaAluno {

	@Override
	public String getDescricao() {
		return "Listar alunos (por média)";
	}

	@Override
	public boolean deveImprimir(Aluno aluno) {
		return true;
	}

	@Override
	public int compare(Aluno o1, Aluno o2) {
		double media1 = o1.calculaMedia();
		double media2 = o2.calculaMedia();

		if (media1 < media2) {
			return -1;
		} else if (media1 > media2) {
			return 1;
		} else {
			return super.compare(o1, o2);
		}
	}

}
