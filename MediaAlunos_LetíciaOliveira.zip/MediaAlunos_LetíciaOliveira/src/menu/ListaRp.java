package menu;

import modelo.Aluno;

public class ListaRp extends ListaAluno {

	@Override
	public String getDescricao() {
		return "Listar alunos reprovados";
	}

	@Override
	public boolean deveImprimir(Aluno aluno) {
		return !aluno.passou();
	}

}
