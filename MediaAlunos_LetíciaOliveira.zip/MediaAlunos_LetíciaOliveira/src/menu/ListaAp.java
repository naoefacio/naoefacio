package menu;

import modelo.Aluno;

public class ListaAp extends ListaAluno {

	@Override
	public String getDescricao() {
		return "Listar alunos aprovados";
	}

	@Override
	public boolean deveImprimir(Aluno aluno) {
		return aluno.passou();
	}

}
