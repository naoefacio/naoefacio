package menu;

import modelo.Aluno;

public class InsereAluno extends ItemDeMenu {

	@Override
	public String getDescricao() {
		return "Inserir aluno";
	}

	@Override
	public boolean executar() {
		String matricula = leitor.lerString("Nº Matrícula: ");
		String nome = leitor.lerString("Nome: ");
		double t1 = leitor.lerDouble("1º Trimestre: ");
                double t2 = leitor.lerDouble("2º Trimestre: ");
		double t3 = leitor.lerDouble("3º Trimestre: ");

		Aluno aluno = new Aluno(matricula, nome);
		aluno.setT1(t1);
		aluno.setT2(t2);
               	aluno.setT3(t3);

		dao.inserir(aluno);

		System.out.println("Aluno cadastrado com sucesso!");

		return false;
	}

}
