package menu;

import modelo.Aluno;

public class ConsultaAluno extends ItemDeMenu {

	@Override
	public String getDescricao() {
		return "Consultar aluno";
	}

	@Override
	public boolean executar() {
		String matricula = leitor.lerString("Matrícula Nº: ");
		
		Aluno aluno = dao.pesquisar(matricula);
		
		if (aluno == null) {
			System.out.println("Aluno não encontrado!");
		}
		else {
			System.out.println("Nome: " + aluno.getNome());
			System.out.println("1º Trimestre: " + aluno.getT1());
			System.out.println("2º Trimestre: " + aluno.getT2());
                        System.out.println("3º Trimestre: " + aluno.getT3());
		}
		
		return false;
	}

}
