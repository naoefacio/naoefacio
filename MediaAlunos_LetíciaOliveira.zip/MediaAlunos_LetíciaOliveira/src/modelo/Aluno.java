package modelo;

public class Aluno {

	private String matricula, nome;
	private double t1, t2, t3;

	public Aluno(String matricula) {
		this(matricula, null);
	}
	
	public Aluno(String matricula, String nome) {
		this(matricula, nome, 0, 0, 0);
	}

	public Aluno(String matricula, String nome, double t1, double t2, double t3) {
		this.matricula = matricula;
		this.nome = nome;
		this.t1 = t1;
		this.t2 = t2;
                this.t3 = t3;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getT1() {
		return t1;
	}
	public void setT1(double t1) {
		this.t1 = t1;
	}

	public double getT2() {
		return t2;
	}
	public void setT2(double t2) {
		this.t2 = t2;
	}
        
        public double getT3() {
		return t3;
	}
	public void setT3(double t3) {
		this.t3 = t3;
        }
        
	public double calculaMedia() {
		return (t1 + t2 + t3) / 3;
	}

	public boolean passou() {
		return calculaMedia() >= 70.0;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((matricula == null) ? 0 : matricula.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		if (matricula == null) {
			if (other.matricula != null)
				return false;
		} else if (!matricula.equals(other.matricula))
			return false;
		return true;
	}
	
}
